<?php
session_start();

 echo'<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><img src="pics/bclogo.png" alt="" width="200" height="30"></a>
        <a class="navbar-brand fs-6" href="#"><img src="pics/call logo.png" alt="" width="10" height="10">+91-9050111218</a>
        <a class="navbar-brand fs-6" href="#"><img src="pics/wholesale logo.png" class="mx-2" alt="" width="15" height="15">Wholesale</a>
     
        ';
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  
    echo    '<form class=" d-flex col-md-6 input-rounded search-box" style="display:none">

                <!-- <input class="form-control" type="search" placeholder=" Search by title,author or ISBN here....."
                aria-label="Search"> -->
                <input type="text" class="form-control input-rounded search-box border-warning"
                    placeholder="Books / Author / ISBN" name="query" value="" id="search-box-btn" autofocus=""
                    required="">
                <button class="btn btn-outline-warning input-rounded">
                    search
                </button>
                <p class="text-light my-0 mx-2">welcome '.$_SESSION['userEmail'].'</p>
                <a href="partial/logout.php" class="btn btn-primary my-4 my-sm-0" type="submit">logout</a>
        </form>';
        }
        else{
            echo'
            <form class=" d-flex col-md-6 input-rounded search-box" style="display:none">

                <!-- <input class="form-control" type="search" placeholder=" Search by title,author or ISBN here....."
                aria-label="Search"> -->
                <input type="text" class="form-control input-rounded search-box border-warning"
                    placeholder="Books / Author / ISBN" name="query" value="" id="search-box-btn" autofocus=""
                    required="">
                <button class="btn btn-outline-warning input-rounded">
                    search
                </button>
        </form>
            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#loginModal">
            Login
        </button>
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#signupModal">
            Sign up
        </button>';
        }
  echo  '</div>

</nav>';


include 'partial/login.php';
include 'partial/signup.php';
if(isset($_GET['signupsuccess']) && $_GET['signupsuccess'] =="true"){
echo'<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong> now you can log in.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
}
?>