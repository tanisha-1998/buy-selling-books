

        <div class="container-fluid bg-dark ">
            <p class="text-center text-light mb-0">

                copyright BookChor 2021 | All Rights Reserved
            </p>

        </div>