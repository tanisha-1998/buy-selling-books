<?php
$showError = "false";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'dbconect.php';
    $email = $_POST['signupEmail'];
    $pass = $_POST['password'];
    $cpass = $_POST['cPassword'];

    $existSql = "select * from `bookusers` where Email = '$email'";
    $result= mysqli_query($conn , $existSql);
    $numRows = mysqli_num_rows($result);
    if($numRows>0){
        $showError = "email already in  use";
    }
    else{
        if($pass == $cpass){
            $hash = password_hash($pass , PASSWORD_DEFAULT);
            $sql = "INSERT INTO `bookusers`(`Email`,`password`,`Date and Time`) VALUES('$email','$hash', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            if($result){
                $showAlert = true;
                header("Location: /BOOKCHOR/welcome.php?signupsuccess=true");
                exit();
        }
        }
        else{
            $showError = "Password do not match";
            
        }
    }
    header("Location: /BOOKCHOR/welcome.php?signupsuccess=false&error=$showError");
}

?>